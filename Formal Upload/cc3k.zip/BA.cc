#include "BA.h"

GridObjectType BA::getObjType() {
    return GridObjectType::BA;
}
