#include "BD.h"

GridObjectType BD::getObjType() {
    return GridObjectType::BD;
}
