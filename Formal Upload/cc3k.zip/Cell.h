//
//  Cell.hpp
//  CC3KFInalProject
//
//  Created by Raymond Tan on 2017-03-23.
//  Copyright © 2017 Raymond Tan. All rights reserved.
//

#ifndef Cell_hpp
#define Cell_hpp

#include "GridObjects.h"


class Cell : public GridObjects{
public:
    /*
    ObstacleType getObsType() override;
    GridObjectType getObjType() override;
     */
    
};

#endif /* Cell_hpp */
