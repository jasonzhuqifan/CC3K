#include "Dwarf.h"
Dwarf::Dwarf(){
    HP = 100;
    Atk = 20;
    Def = 30;
    MaxHP = 100;
}


Dwarf::~Dwarf(){}
