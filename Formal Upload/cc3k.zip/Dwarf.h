//
//  Dwarf.hpp
//  CC3FinalProject
//
//  Created by Raymond Tan on 2017-03-25.
//
//

#ifndef Dwarf_hpp
#define Dwarf_hpp

#include "Enemy.h"

class Dwarf : public Enemy{
public:
    Dwarf();
    ~Dwarf();
};

#endif /* Dwarf_hpp */
