//
//  FloorTile.hpp
//  CC3KFInalProject
//
//  Created by Raymond Tan on 2017-03-23.
//  Copyright © 2017 Raymond Tan. All rights reserved.
//

#ifndef FloorTile_hpp
#define FloorTile_hpp

#include "Cell.h"

class FloorTile : public Cell{
public:
    ObstacleType getObsType() override;
    GridObjectType getObjType() override;
};

#endif /* FloorTile_hpp */
