#include "Halfling.h"
Halfling::Halfling(){
    HP = 100;
    Atk = 15;
    Def = 20;
    MaxHP = 100;
}

Halfling::~Halfling(){}
