//
//  Halfling.hpp
//  CC3KFInalProject
//
//  Created by Raymond Tan on 2017-03-23.
//  Copyright © 2017 Raymond Tan. All rights reserved.
//

#ifndef Halfling_hpp
#define Halfling_hpp

#include "Enemy.h"

class Halfling : public Enemy{
public:
    Halfling();
    ~Halfling();
};

#endif /* Halfling_hpp */
