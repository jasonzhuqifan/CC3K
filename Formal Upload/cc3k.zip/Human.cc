#include "Human.h"

Human::Human(){
    HP = 140;
    Atk = 20;
    Def = 20;
    MaxHP = 140;
    gold = 2;
}

Human::~Human(){}
