#ifndef Human_hpp
#define Human_hpp

#include "Enemy.h"

class Human : public Enemy{
public:
    Human();
    ~Human();
};

#endif /* Human_hpp */
