#include "Merchant.h"

Merchant::Merchant(){
    HP = 30;
    Atk = 70;
    Def = 5;
    MaxHP = 30;
    isneutral = true;
    gold = 4;
}

Merchant::~Merchant(){}
