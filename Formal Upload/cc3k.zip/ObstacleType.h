#ifndef ObstacleType_hpp
#define ObstacleType_hpp

enum class ObstacleType{BolckAll,BlockEnemy,BlockNone};

#endif
