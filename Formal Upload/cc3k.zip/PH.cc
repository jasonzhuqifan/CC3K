#include "PH.h"

GridObjectType PH::getObjType() {
    return GridObjectType::PH;
}
