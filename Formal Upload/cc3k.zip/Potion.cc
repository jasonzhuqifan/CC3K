#include "Potion.h"

ObstacleType Potion::getObsType() {
    return ObstacleType::BolckAll;
}

Potion::~Potion() {}
