#include "RH.h"

GridObjectType RH::getObjType() {
    return GridObjectType::RH;
}
