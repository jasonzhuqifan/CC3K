//
//  SubscriptionType.hpp
//  CC3FinalProject
//
//  Created by Raymond Tan on 2017-03-25.
//
//

#ifndef SubscriptionType_hpp
#define SubscriptionType_hpp

enum class SubscriptionType{All, attackOnly, displayOnly};

#endif /* SubscriptionType_hpp */
