#include "WA.h"

GridObjectType WA::getObjType() {
    return GridObjectType::WA;
}
