#include "WD.h"

GridObjectType WD::getObjType() {
    return GridObjectType::WD;
}
